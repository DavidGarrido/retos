"""
El movimiento se describe en función del desplazamiento (x), tiempo (t), velocidad (v), y aceleración (a). La velocidad es la rapidez de cambio del desplazamiento y la aceleración es la rapidez de cambio de la velocidad. La velocidad y aceleración medias se definen por las siguientes relaciones

    v = x/t
    a = v/t

"""
def simulador_movimiento(a,t):
  
    # Hallar la velocidad
    v = a * t 
    # Hallar distancia segundo a segundo
    for i in range(t+1):
        x = v * i
        print("Se ha recorrido",x,"metros en ",i," segundos")
    
    return "No implementada aún"


"""
Series y no las de Netflix

Una serie geométrica es la serie de una sucesión geométrica: aquella en la que cada término se obtiene multiplicando el anterior por una constante r.

Por ejemplo

S= 1 + 1/2 +1/4 +1/8 + 1/16 + .....

¿Ya adivinas lo que debes hacer?

Así es, necesitamos una función que dada un numero de términos (mayor o igual a cero):

    retorne el valor de la sumatoria para el número de terminos de la serie dada
    muestre las sumatorias parciales mientras hace el cálculo total

En el archivo funciones_ciclos.py esta la línea base para implementar esta función.
"""


def calculador_series(n):
    #TODO Comentar código
    #TODO Implementar la función

    sumatoria = 0
    dividiendo = 1

    for i in range(n):
        sumatoria = sumatoria + (1 / dividiendo)
        dividiendo = dividiendo * 2
        print("Sumatoria parcial:",sumatoria)

"""
Triangulares

Vamos a hacer un triangulo con números enteros consecutivos, asi como el que se muestra a continuación que es un triángulo de 5 pisos.

1
2      3
4      5     6
7      8     9       10
11    12   13    14    15
¿Que debo hacer?

Vamos a implementar una función que permita construir triángulos de números enteros dado un número de pisos. (mayor a cero)

En el archivo funciones_ciclos.py esta la línea base para implementar esta función.
"""


def constructor_triangulos(pisos):
    if pisos > 0:
        num = 1 #variable contador
        for i in range(0, pisos):#ciclo para recorrer los pisos
            for j in range(0, i+1):#si esta en el rango de piso
                if num < 10:#condicional para anteponer el cero en numeros menores de 10
                    print('0'+str(num), end=" ")
                else:
                    print(num, end=" ")#imprime el numero y finaliza con un espacio para que no termine en salto de linea
                num = num + 1#despues de imprimir se aumenta 
            print("\r")
    else:
        print("El numero debe ser mayor a 0")
    