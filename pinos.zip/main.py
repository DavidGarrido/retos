"""
¿Y yo que tengo que ver en este cuento?

Para hacer nuestros primeros "pinos" en simulación, 
vamos a realizar un programa que dada una aceleración 
(a) constante y un tiempo (t), muestre la distancia a 
la que va el objeto segundo a segundo hasxta llegar a (t).

En el archivo funciones_ciclos.py esta la 
línea base para implementar esta función.
"""

import funciones as func

func.simulador_movimiento(2, 3)
print()
func.calculador_series(5)
print()
func.constructor_triangulos(5)